-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 29 Ara 2023, 13:16:35
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `localhost`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `deneyim`
--

CREATE TABLE `deneyim` (
  `id` int(100) NOT NULL,
  `adsoyaddeneyim` varchar(50) NOT NULL,
  `epostadeneyim` varchar(50) NOT NULL,
  `surusdeneyimi` varchar(50) NOT NULL,
  `enyuksekhiz` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `deneyim`
--

INSERT INTO `deneyim` (`id`, `adsoyaddeneyim`, `epostadeneyim`, `surusdeneyimi`, `enyuksekhiz`) VALUES
(1, '', '', '', 0),
(2, 'dfsfsdf', 'akgunemirhan@hotmail.com', 'asdsadsadasdsa', 2321),
(5, 'sadsadsadsafdsfdsgfdgfdhgfdhdf', 'mehmet@hotmail.com', 'asdsadsadasdsaasdasfscfgdgdfgdfgfdg', 23134),
(6, 'ranasafsafdsfsfdsfsd', 'afafdsf@gmail.com', 'sadasdsafsdfds', 324),
(7, 'Mehmet Burak Meydancı', 'mehmet.meydanci@ogr.gelisim.edu.tr', 'çok iyi gidiyor', 180);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim`
--

CREATE TABLE `iletisim` (
  `Id` int(11) NOT NULL,
  `Adsoyad` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `eposta` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Konu` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_general_ci;

--
-- Tablo döküm verisi `iletisim`
--

INSERT INTO `iletisim` (`Id`, `Adsoyad`, `eposta`, `Konu`) VALUES
(1, 'emirhan akgü', 'akgunemirhan@hotmail.com', 'muhteşem bir deneyimdi'),
(6, 'mehmet', 'mehmet@hotmail.com', 'inanılmaz'),
(7, 'rana', 'rana@gmail.com', 'remziye'),
(8, 'a', 'adsadasdaq@hotmail.com', 'sadasfdsfdsgfsdgfgsdg'),
(9, 'son deneme', 'sondeneme@gmail.com', 'deneme'),
(10, 'emir yakın', 'emiryakin@hotmail.com', 'radyomun ayarlarında sıkıntı yaşıyorum.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `satisdanismanligi`
--

CREATE TABLE `satisdanismanligi` (
  `id` int(100) NOT NULL,
  `adsoyadsatis` varchar(50) NOT NULL,
  `epostasatis` varchar(50) NOT NULL,
  `ozelliksatis` varchar(100) NOT NULL,
  `butcesatis` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `satisdanismanligi`
--

INSERT INTO `satisdanismanligi` (`id`, `adsoyadsatis`, `epostasatis`, `ozelliksatis`, `butcesatis`) VALUES
(1, 'mehmet', '0', 'hızlı olması', 4),
(2, 'asdsadasdsa', 'adsadasdaq@hotmail.com', 'muhteşemdi', 3),
(10, 'mehmet', 'mehmet@hotmail.com', 'hızlı olması', 2),
(11, 'afasfadsad', 'fdfhdfhfdh@gmail.com', 'yanlaması', 1),
(13, 'emirhan akgü', 'aaa@gmail.com', 'hızlı olması', 3),
(14, 'aysun', 'aysun@hotmail.com', 'sedann', 23),
(15, 'egementüylü', 'egemen_tuy@hotmail.com', 'konfor,hız, tasarım', 100);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `deneyim`
--
ALTER TABLE `deneyim`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `eposta` (`epostadeneyim`);

--
-- Tablo için indeksler `iletisim`
--
ALTER TABLE `iletisim`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `E-posta` (`eposta`),
  ADD UNIQUE KEY `Adsoyad` (`Adsoyad`);

--
-- Tablo için indeksler `satisdanismanligi`
--
ALTER TABLE `satisdanismanligi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `epostasatis` (`epostasatis`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `deneyim`
--
ALTER TABLE `deneyim`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `iletisim`
--
ALTER TABLE `iletisim`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Tablo için AUTO_INCREMENT değeri `satisdanismanligi`
--
ALTER TABLE `satisdanismanligi`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
